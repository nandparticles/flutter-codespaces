package com.suwayomi.tachidesk_sorayomi

import io.flutter.embedding.android.FlutterActivity

import dev.darttools.flutter_android_volume_keydown.FlutterAndroidVolumeKeydownActivity;

class MainActivity: FlutterAndroidVolumeKeydownActivity() {
}
