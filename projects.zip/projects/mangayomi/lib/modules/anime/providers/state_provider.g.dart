// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$subtitleSettingsStateHash() =>
    r'4b89ea55392e662651d5aeee4dfce2fcd23ac0e7';

/// See also [SubtitleSettingsState].
@ProviderFor(SubtitleSettingsState)
final subtitleSettingsStateProvider = AutoDisposeNotifierProvider<
    SubtitleSettingsState, PlayerSubtitleSettings>.internal(
  SubtitleSettingsState.new,
  name: r'subtitleSettingsStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$subtitleSettingsStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SubtitleSettingsState = AutoDisposeNotifier<PlayerSubtitleSettings>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
