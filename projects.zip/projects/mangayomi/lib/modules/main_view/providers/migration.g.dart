// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'migration.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$migrationHash() => r'7354a8368b73fdfcfd284848b9837b4bc9047e7f';

/// See also [migration].
@ProviderFor(migration)
final migrationProvider = AutoDisposeFutureProvider<void>.internal(
  migration,
  name: r'migrationProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$migrationHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef MigrationRef = AutoDisposeFutureProviderRef<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
