// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$mangaHomeDisplayTypeStateHash() =>
    r'48582d80d07c966d5765f20ecc92947e9dd0881c';

/// See also [MangaHomeDisplayTypeState].
@ProviderFor(MangaHomeDisplayTypeState)
final mangaHomeDisplayTypeStateProvider = AutoDisposeNotifierProvider<
    MangaHomeDisplayTypeState, DisplayType>.internal(
  MangaHomeDisplayTypeState.new,
  name: r'mangaHomeDisplayTypeStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$mangaHomeDisplayTypeStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MangaHomeDisplayTypeState = AutoDisposeNotifier<DisplayType>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
