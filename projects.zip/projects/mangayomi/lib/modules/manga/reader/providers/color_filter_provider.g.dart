// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'color_filter_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$customColorFilterStateHash() =>
    r'5138b52d1465b1e0109b9757375e8ce4fbeb21d9';

/// See also [CustomColorFilterState].
@ProviderFor(CustomColorFilterState)
final customColorFilterStateProvider = AutoDisposeNotifierProvider<
    CustomColorFilterState, CustomColorFilter?>.internal(
  CustomColorFilterState.new,
  name: r'customColorFilterStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$customColorFilterStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CustomColorFilterState = AutoDisposeNotifier<CustomColorFilter?>;
String _$enableCustomColorFilterStateHash() =>
    r'21d9944242971b5a6d034b61cc413d04b3075730';

/// See also [EnableCustomColorFilterState].
@ProviderFor(EnableCustomColorFilterState)
final enableCustomColorFilterStateProvider =
    AutoDisposeNotifierProvider<EnableCustomColorFilterState, bool>.internal(
  EnableCustomColorFilterState.new,
  name: r'enableCustomColorFilterStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$enableCustomColorFilterStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$EnableCustomColorFilterState = AutoDisposeNotifier<bool>;
String _$colorFilterBlendModeStateHash() =>
    r'dc975e92e7217d4803b73d1850ca5d9d3d4d8575';

/// See also [ColorFilterBlendModeState].
@ProviderFor(ColorFilterBlendModeState)
final colorFilterBlendModeStateProvider = AutoDisposeNotifierProvider<
    ColorFilterBlendModeState, ColorFilterBlendMode>.internal(
  ColorFilterBlendModeState.new,
  name: r'colorFilterBlendModeStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$colorFilterBlendModeStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ColorFilterBlendModeState = AutoDisposeNotifier<ColorFilterBlendMode>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
