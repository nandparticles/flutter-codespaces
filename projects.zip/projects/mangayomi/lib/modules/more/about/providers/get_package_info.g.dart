// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_package_info.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$getPackageInfoHash() => r'41844966a85f413f78ccddac1f5c235d2547c33f';

/// See also [getPackageInfo].
@ProviderFor(getPackageInfo)
final getPackageInfoProvider = AutoDisposeFutureProvider<PackageInfo>.internal(
  getPackageInfo,
  name: r'getPackageInfoProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$getPackageInfoHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef GetPackageInfoRef = AutoDisposeFutureProviderRef<PackageInfo>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
