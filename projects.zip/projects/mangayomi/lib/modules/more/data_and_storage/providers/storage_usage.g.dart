// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'storage_usage.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$totalChapterCacheSizeStateHash() =>
    r'83bf78de5ef674d61d3a9311061ef0933e59109b';

/// See also [TotalChapterCacheSizeState].
@ProviderFor(TotalChapterCacheSizeState)
final totalChapterCacheSizeStateProvider =
    AutoDisposeNotifierProvider<TotalChapterCacheSizeState, String>.internal(
  TotalChapterCacheSizeState.new,
  name: r'totalChapterCacheSizeStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$totalChapterCacheSizeStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$TotalChapterCacheSizeState = AutoDisposeNotifier<String>;
String _$clearChapterCacheOnAppLaunchStateHash() =>
    r'6fdefd7a3bdc4309dd596dad43891c654ec2ba70';

/// See also [ClearChapterCacheOnAppLaunchState].
@ProviderFor(ClearChapterCacheOnAppLaunchState)
final clearChapterCacheOnAppLaunchStateProvider = AutoDisposeNotifierProvider<
    ClearChapterCacheOnAppLaunchState, bool>.internal(
  ClearChapterCacheOnAppLaunchState.new,
  name: r'clearChapterCacheOnAppLaunchStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$clearChapterCacheOnAppLaunchStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ClearChapterCacheOnAppLaunchState = AutoDisposeNotifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
