// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'incognito_mode_state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$incognitoModeStateHash() =>
    r'54fc89df3bffd0b9665f04d9c9c2f75532925804';

/// See also [IncognitoModeState].
@ProviderFor(IncognitoModeState)
final incognitoModeStateProvider =
    AutoDisposeNotifierProvider<IncognitoModeState, bool>.internal(
  IncognitoModeState.new,
  name: r'incognitoModeStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$incognitoModeStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$IncognitoModeState = AutoDisposeNotifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
