// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_font_family.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$appFontFamilyHash() => r'7f115012111256848d806e47382db1f8abcff5ec';

/// See also [AppFontFamily].
@ProviderFor(AppFontFamily)
final appFontFamilyProvider =
    AutoDisposeNotifierProvider<AppFontFamily, String?>.internal(
  AppFontFamily.new,
  name: r'appFontFamilyProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$appFontFamilyHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AppFontFamily = AutoDisposeNotifier<String?>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
