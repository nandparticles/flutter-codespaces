// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'blend_level_state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$blendLevelStateHash() => r'ceb7965073b2d6676a91acbe662bfa881f2f5e30';

/// See also [BlendLevelState].
@ProviderFor(BlendLevelState)
final blendLevelStateProvider =
    AutoDisposeNotifierProvider<BlendLevelState, double>.internal(
  BlendLevelState.new,
  name: r'blendLevelStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$blendLevelStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$BlendLevelState = AutoDisposeNotifier<double>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
