// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'date_format_state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$dateFormatStateHash() => r'094aa68b09b654de97be6a59c6d593f30e3bdf79';

/// See also [DateFormatState].
@ProviderFor(DateFormatState)
final dateFormatStateProvider =
    AutoDisposeNotifierProvider<DateFormatState, String>.internal(
  DateFormatState.new,
  name: r'dateFormatStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$dateFormatStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$DateFormatState = AutoDisposeNotifier<String>;
String _$relativeTimesTampsStateHash() =>
    r'e515ea30e71143ee60f86a02320e8b1f50b5a955';

/// See also [RelativeTimesTampsState].
@ProviderFor(RelativeTimesTampsState)
final relativeTimesTampsStateProvider =
    AutoDisposeNotifierProvider<RelativeTimesTampsState, int>.internal(
  RelativeTimesTampsState.new,
  name: r'relativeTimesTampsStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$relativeTimesTampsStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RelativeTimesTampsState = AutoDisposeNotifier<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
