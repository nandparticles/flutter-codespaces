// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'flex_scheme_color_state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$flexSchemeColorStateHash() =>
    r'5c535382cc52e144426fa36dc20ea614d6288f53';

/// See also [FlexSchemeColorState].
@ProviderFor(FlexSchemeColorState)
final flexSchemeColorStateProvider =
    AutoDisposeNotifierProvider<FlexSchemeColorState, FlexSchemeColor>.internal(
  FlexSchemeColorState.new,
  name: r'flexSchemeColorStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$flexSchemeColorStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$FlexSchemeColorState = AutoDisposeNotifier<FlexSchemeColor>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
