// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pure_black_dark_mode_state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$pureBlackDarkModeStateHash() =>
    r'2dd98617810c8677341dc5cc485d226e6d610cf5';

/// See also [PureBlackDarkModeState].
@ProviderFor(PureBlackDarkModeState)
final pureBlackDarkModeStateProvider =
    AutoDisposeNotifierProvider<PureBlackDarkModeState, bool>.internal(
  PureBlackDarkModeState.new,
  name: r'pureBlackDarkModeStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$pureBlackDarkModeStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PureBlackDarkModeState = AutoDisposeNotifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
