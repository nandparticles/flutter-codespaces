// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'theme_mode_state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$themeModeStateHash() => r'49a0f05f3d5eb1fcd49ec3c8c0d0b57a732b54fc';

/// See also [ThemeModeState].
@ProviderFor(ThemeModeState)
final themeModeStateProvider =
    AutoDisposeNotifierProvider<ThemeModeState, bool>.internal(
  ThemeModeState.new,
  name: r'themeModeStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$themeModeStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ThemeModeState = AutoDisposeNotifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
