// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'browse_state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$onlyIncludePinnedSourceStateHash() =>
    r'77c4bff96e186c4bce0a5c312871ceec88a269d0';

/// See also [OnlyIncludePinnedSourceState].
@ProviderFor(OnlyIncludePinnedSourceState)
final onlyIncludePinnedSourceStateProvider =
    AutoDisposeNotifierProvider<OnlyIncludePinnedSourceState, bool>.internal(
  OnlyIncludePinnedSourceState.new,
  name: r'onlyIncludePinnedSourceStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$onlyIncludePinnedSourceStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$OnlyIncludePinnedSourceState = AutoDisposeNotifier<bool>;
String _$autoUpdateExtensionsStateHash() =>
    r'30ce3c558504e005f9c85e2fc969ab7a581510cd';

/// See also [AutoUpdateExtensionsState].
@ProviderFor(AutoUpdateExtensionsState)
final autoUpdateExtensionsStateProvider =
    AutoDisposeNotifierProvider<AutoUpdateExtensionsState, bool>.internal(
  AutoUpdateExtensionsState.new,
  name: r'autoUpdateExtensionsStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$autoUpdateExtensionsStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AutoUpdateExtensionsState = AutoDisposeNotifier<bool>;
String _$checkForExtensionsUpdateStateHash() =>
    r'1b1f22a50e0862a7d643fbe0fcb5d563bd0169c2';

/// See also [CheckForExtensionsUpdateState].
@ProviderFor(CheckForExtensionsUpdateState)
final checkForExtensionsUpdateStateProvider =
    AutoDisposeNotifierProvider<CheckForExtensionsUpdateState, bool>.internal(
  CheckForExtensionsUpdateState.new,
  name: r'checkForExtensionsUpdateStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$checkForExtensionsUpdateStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CheckForExtensionsUpdateState = AutoDisposeNotifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
