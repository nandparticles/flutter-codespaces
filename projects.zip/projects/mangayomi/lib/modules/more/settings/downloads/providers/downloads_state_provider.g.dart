// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'downloads_state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$onlyOnWifiStateHash() => r'613d0fd2a72fdfeb0c8da05dc8ed4144cc8df6f5';

/// See also [OnlyOnWifiState].
@ProviderFor(OnlyOnWifiState)
final onlyOnWifiStateProvider =
    AutoDisposeNotifierProvider<OnlyOnWifiState, bool>.internal(
  OnlyOnWifiState.new,
  name: r'onlyOnWifiStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$onlyOnWifiStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$OnlyOnWifiState = AutoDisposeNotifier<bool>;
String _$saveAsCBZArchiveStateHash() =>
    r'81c4d07dc96f0fae33274f2067911e5b94ac6161';

/// See also [SaveAsCBZArchiveState].
@ProviderFor(SaveAsCBZArchiveState)
final saveAsCBZArchiveStateProvider =
    AutoDisposeNotifierProvider<SaveAsCBZArchiveState, bool>.internal(
  SaveAsCBZArchiveState.new,
  name: r'saveAsCBZArchiveStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$saveAsCBZArchiveStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SaveAsCBZArchiveState = AutoDisposeNotifier<bool>;
String _$downloadLocationStateHash() =>
    r'dba216dd8de1206c1c272d0f76684e016e10417f';

/// See also [DownloadLocationState].
@ProviderFor(DownloadLocationState)
final downloadLocationStateProvider = AutoDisposeNotifierProvider<
    DownloadLocationState, (String, String)>.internal(
  DownloadLocationState.new,
  name: r'downloadLocationStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$downloadLocationStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$DownloadLocationState = AutoDisposeNotifier<(String, String)>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
