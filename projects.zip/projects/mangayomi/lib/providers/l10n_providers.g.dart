// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'l10n_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$l10nLocaleStateHash() => r'1c6cb9d6c0a56d54a6a5e7bc1b2dbc6c29538593';

/// See also [L10nLocaleState].
@ProviderFor(L10nLocaleState)
final l10nLocaleStateProvider =
    AutoDisposeNotifierProvider<L10nLocaleState, Locale>.internal(
  L10nLocaleState.new,
  name: r'l10nLocaleStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$l10nLocaleStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$L10nLocaleState = AutoDisposeNotifier<Locale>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
