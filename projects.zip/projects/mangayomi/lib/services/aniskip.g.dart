// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'aniskip.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$aniSkipHash() => r'2e5d19b025a2207ff64da7bf7908450ea9e5ff8c';

/// See also [AniSkip].
@ProviderFor(AniSkip)
final aniSkipProvider = AutoDisposeNotifierProvider<AniSkip, void>.internal(
  AniSkip.new,
  name: r'aniSkipProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$aniSkipHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AniSkip = AutoDisposeNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
