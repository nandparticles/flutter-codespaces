import 'package:flutter/material.dart';

final popupAnimationStyle =
    AnimationStyle(curve: Curves.easeInOutCubicEmphasized);
