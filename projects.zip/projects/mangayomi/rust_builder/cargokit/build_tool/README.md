/// This is copied from Cargokit (which is the official way to use it currently)
/// Details: https://fzyzcjy.github.io/flutter_rust_bridge/manual/integrate/builtin

A sample command-line application with an entrypoint in `bin/`, library code
in `lib/`, and example unit test in `test/`.
